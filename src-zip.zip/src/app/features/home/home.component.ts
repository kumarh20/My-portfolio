import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatCardModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {
  // Array of profile images - using the same image multiple times for now
  // You can replace these with your actual images later
  profileImages: string[] = [
    '../../../assets/images/hk.jpeg',
    '../../../assets/images/hk1.jpeg',
    '../../../assets/images/hk2.jpeg',
    '../../../assets/images/hk3.jpeg', 
    '../../../assets/images/hk4.jpeg',
    '../../../assets/images/hk5.jpeg',
  ];

  currentImageIndex: number = 0;
  private intervalId: any;
  private autoPlayDelay: number = 4000; // 4 seconds

  ngOnInit(): void {
    this.startAutoPlay();
  }

  ngOnDestroy(): void {
    this.stopAutoPlay();
  }

  nextImage(): void {
    this.currentImageIndex = (this.currentImageIndex + 1) % this.profileImages.length;
    this.resetAutoPlay();
  }

  previousImage(): void {
    this.currentImageIndex =
      this.currentImageIndex === 0
        ? this.profileImages.length - 1
        : this.currentImageIndex - 1;
    this.resetAutoPlay();
  }

  goToImage(index: number): void {
    this.currentImageIndex = index;
    this.resetAutoPlay();
  }

  private startAutoPlay(): void {
    this.intervalId = setInterval(() => {
      this.nextImage();
    }, this.autoPlayDelay);
  }

  private stopAutoPlay(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  private resetAutoPlay(): void {
    this.stopAutoPlay();
    this.startAutoPlay();
  }
}
